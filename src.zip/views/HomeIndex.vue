<template>
  <div class="container">Homepage</div>
</template>

<script>
export default {};
</script>

<style></style>
