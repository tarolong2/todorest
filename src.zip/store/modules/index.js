import toast from "./toast/index.js";
export default {
  toast,
};
