<template>
  <div class="container">
    <h1>About</h1>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
